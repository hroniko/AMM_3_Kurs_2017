#include <iostream>
#include <string>
#include <cmath>
#include <clocale>
#include <ctime>
#include <chrono> // Для работы с датой и временем

using namespace std;


// Класс Расписание
class Schedule {
protected:

    // Дата и время записи
    std::tm datetime_tm = {0};

    // ФИО
    string firstname;
    string lastname;
    string surname;

    // Ссылка на следующую запись
    Schedule * sc_next = NULL;

public:

    // Конструктор с параметрами
    Schedule(string fName, string lName, string sName) {
        firstname = fName;
        lastname = lName;
        surname = sName;
    }

    Schedule(string fName, string lName, string sName, int yy, int mm, int dd, int hour, int minute) {
        firstname = fName;
        lastname = lName;
        surname = sName;

        setYY(yy);
        setMM(mm);
        setDD(dd);

        setHour(hour);
        setMinute(minute);
    }



    // Набор геттеров и сеттеров

    // Дата:

    void setYY(int &year){
        datetime_tm.tm_year = year - 1900;
    }

    int getYY() {
        return datetime_tm.tm_year + 1900;
    }
    //

    void setMM(int &month) {
        datetime_tm.tm_mon = month - 1;
    }

    int getMM() {
        return datetime_tm.tm_mon + 1;
    }
    //

    void setDD(int &day) {
        datetime_tm.tm_mday = day;
    }

    int getDD() {
        return datetime_tm.tm_mday;
    }

    // Время:

    void setHour(int &hour){
        datetime_tm.tm_hour = hour;
    }

    int getHour() {
        return datetime_tm.tm_hour;
    }
    //

    void setMinute(int &minute){
        datetime_tm.tm_min = minute;
    }

    int getMinute() {
        return datetime_tm.tm_min;
    }



    // ФИО
    string getFirstname() {
        return firstname;
    }

    void setFirstname(string &fname) {
        firstname = fname;
    }

    string getLastname() {
        return lastname;
    }

    void setLastname(string &lname) {
        lastname = lname;
    }

    string &getSurname() {
        return surname;
    }

    void setSurname(string &sname) {
        surname = sname;
    }
    //

    // Ссылка на следующий элемент расписания:
    Schedule * getNext(){
        return sc_next;
    }

    void setNext(Schedule * sc){
        sc_next = sc;
    }




    // Метод получения информации о Студенте
    string getInfo() {

        string info = "Запись на " + std::to_string(getYY()) + "-" + // год
                ( getMM() > 9 ? std::to_string(getMM()) : "0" + std::to_string(getMM()) ) + "-" + // месяц
                ( getDD() > 9 ? std::to_string(getDD()) : "0" + std::to_string(getDD()) ) + " "; // день

        info += ( getHour() > 9 ? std::to_string(getHour()) : "0" + std::to_string(getHour()) ) + ":" + // час
                ( getMinute() > 9 ? std::to_string(getMinute()) : "0" + std::to_string(getMinute()) ) + "\t"; // минуты

        info += firstname + " " + lastname + " " + surname; // ФИО
        return info;
    }

};

// Функция добавления новой записи в расписание
Schedule * addSchedule(Schedule * head, string fName, string lName, string sName, int yy, int mm, int dd, int hour, int minute){
    Schedule *new_schedule = new Schedule(fName, lName, sName);
    (*new_schedule).setYY(yy);
    (*new_schedule).setMM(mm);
    (*new_schedule).setDD(dd);

    (*new_schedule).setHour(hour);
    (*new_schedule).setMinute(minute);

    (*head).setNext(new_schedule);

    return new_schedule;
}

// Функция обхода всего списка и печати
void printSchedule(Schedule * root){
    while ((*root).getNext() != NULL){
        root = (*root).getNext();
        cout << (*root).getInfo() << endl;
    }
}

// Функция определения возможности вставить запись между двумя записями
bool okBetween(Schedule * sc1, Schedule * sc2){
    if (sc1 == NULL) return false; // Не можем прикрепить!!
    if (sc2 == NULL) return true; // А если первая запись существует, но второй нет, то смело вешаем
    // Иначе обе записи существуют, надо понять, как далеко они друг от друга, если между ними больше одного часа, то все хорошо
    if ((* sc2).getYY() - (* sc1).getYY() > 1) return true; // Больше одного года

    if ((* sc2).getMM() - (* sc1).getMM() > 1) return true; // Больше одного месяца

    if ((* sc2).getDD() - (* sc1).getDD() > 1) return true; // Больше одного дня

    if ( ((* sc2).getHour() - (* sc1).getHour()) * 60 + (* sc2).getMinute() - (* sc1).getMinute() >= 60 ) return true; // больше 60 минут
    return false; // Иначе нельзя
}

// Функция определения времени в минутах между двумя записями:
long minutesBetween(Schedule * sc1, Schedule * sc2){

    long res = (* sc2).getYY() - (* sc1).getYY();
    res = res * 12 + (* sc2).getMM() - (* sc1).getMM();
    res = res * 30 + (* sc2).getDD() - (* sc1).getDD();
    res = res * 24 + (* sc2).getHour() - (* sc1).getHour();
    res = res * 60 + (* sc2).getMinute() - (* sc1).getMinute();

    return res;
}



// Функция добавления новой записи в расписание
Schedule * addSchedule2(Schedule * head, string fName, string lName, string sName, int yy, int mm, int dd, int hour, int minute){

    // Создание новой записи
    Schedule *new_schedule = new Schedule(fName, lName, sName);
    (*new_schedule).setYY(yy);
    (*new_schedule).setMM(mm);
    (*new_schedule).setDD(dd);

    (*new_schedule).setHour(hour);
    (*new_schedule).setMinute(minute);
    //


    // 1 Если есть только один корневой элемент
    if ((*head).getNext() == NULL){
        (*head).setNext(new_schedule);
        return head;
    }

    // Проверяем, вдруг можно поставить новую запись перед текущей
    if (minutesBetween(new_schedule, head) >= 60L){
        // то можно записать впереди
        (*new_schedule).setNext(head);

        return new_schedule;

    }
/*
    // Иначе нельзя, надо искать место, куда вставить
    Schedule * root = (*head).getNext();
    while (minutesBetween(root, new_schedule) < 0 ){
/////////////////
        cout << minutesBetween(root, new_schedule) << endl;
        if ((*root).getNext() == NULL){
            // то можно записать в конец
            (*root).setNext(new_schedule);

            return head;
        }
        // Иначе движемся дальше
        root = (*root).getNext();
    }
*/

    // Иначе нельзя, надо искать место, куда вставить
    Schedule * root = head;
    while ((*root).getNext() != NULL){
        cout << (*root).getSurname() << endl;
        cout << (*new_schedule).getSurname() << endl;
        cout << minutesBetween(root, new_schedule) << endl;

        if ((minutesBetween(root, new_schedule) >= 60L) & (minutesBetween(new_schedule, (*root).getNext()) >= 60L)){
            // нашли место для вставки!
            (*new_schedule).setNext((*root).getNext());
            (*root).setNext(new_schedule);
            return head;
        }
        // Иначе движемся дальше
        root = (*root).getNext();
    }
/*
    // А дальше мы добрались до момента, когда уже можно искать место для вставки
    while ((*root).getNext() != NULL){
        cout << (*root).getSurname() << endl;
        cout << (*new_schedule).getSurname() << endl;
        cout << minutesBetween(root, new_schedule) << endl;
        if (minutesBetween(root, new_schedule) >= 60){
            // нашли место для вставки!
            (*new_schedule).setNext((*root).getNext());
            (*root).setNext(new_schedule);
            return head;
        }
    }
*/
    // И, наконец, если никуда не всунули, то встраиваем в конец:

    (*root).setNext(new_schedule);

    return head;
}


// Функция изменения времени записи так, чтобы она помещалась следом за впередиидущей:
// Первый параметр - запись в расписании, на который ориентируемся, второй - запись, которую изменяем
Schedule * optimizeTime(Schedule * sc1, Schedule * sc2){

    string before = (*sc2).getInfo(); // Информация о записи до изменения


    long res = (* sc2).getYY() - (* sc1).getYY();
    res = res * 12 + (* sc2).getMM() - (* sc1).getMM();
    res = res * 30 + (* sc2).getDD() - (* sc1).getDD();
    res = res * 24 + (* sc2).getHour() - (* sc1).getHour();
    res = res * 60 + (* sc2).getMinute() - (* sc1).getMinute();

    return res;
}




int main()
{

    setlocale(LC_ALL, "Russian");

/*
    Schedule *head = new Schedule("Root", "Root", "Root"); // Корневой элемент
    Schedule * tail = addSchedule(head, "Иван", "Иванович", "Иванов", 2017, 10, 28, 7, 55);

    tail = addSchedule(tail, "Петр", "Петрович", "Петров", 2017, 10, 29, 14, 00);
    tail = addSchedule(tail, "Сидор", "Сидорович", "Сидоров", 2017, 10, 29, 15, 00);
*/


    Schedule *head = new Schedule("Root", "Root", "Root"); // Корневой элемент
    head = addSchedule2(head, "Иван", "Иванович", "Иванов", 2017, 10, 21, 7, 55);

    head = addSchedule2(head, "Петр", "Петрович", "Петров", 2017, 10, 29, 17, 20);
    head = addSchedule2(head, "Сидор", "Сидорович", "Сидоров", 2017, 10, 29, 15, 30);

    printSchedule(head);


    /*
    Schedule *sc1 = new Schedule( "Петр", "Петрович", "Петров", 2017, 10, 28, 14, 00);
    Schedule *sc2 = new Schedule( "Петр2", "Петрович2", "Петров2", 2017, 10, 29, 14, 00);

    cout << minutesBetween(sc1, sc2) << endl;
    cout << 24*60 << endl;

*/

    // system("pause"); // Команда задержки экрана, только для Windows

    return 0;
}